# Inhouse Competition - JIIT Optica Student Chapter
## Topic-College Realted

## Team-code stomp


### [Problem Statement]()- Many time student have visited many websites / blogs for find where is Job opening is there or not, Many cases they miss the opportunity. In this modern world bombard with information make students confused, one mentor in form of senior can definitely help how to web dev, Android dev ,AWS and many more questions 




## INTRODUCTION

The Placement Management System is a web application for the training and  placement department of our college. This system can be accessed throughout the  organization with proper login credentials. Students will be able to upload their  personal and educational information which will be managed efficiently by the  system. It intends to provide a fast access to the placement procedures and related  activities and ensures to maintain the details of the student secure. The key feature of  this project is that it is a onetime registration enabled system. This project will aid  colleges to practice full IT deployment.

Website- https://code-placement.000webhostapp.com/index.php


## Features
- Separate Login Page For Admin, Coordinater and Student
- Interactive Dashboard
- Coordinater can Update the drive and check the applied and modify accordingly
- Admin can Approve and reject request of All type of registration 
- Admin can post notice to all students and coordinater separately
- Upload technical papers
- View Student and Company Profile
- Interactive Contact us Page



## Technology and Framework Used
- HTML
- CSS
- Javascript
- Reat
- Bootstrap
- PHP
- Mysql











# PROJECT SNAPSHOTS

- Home Page







![Screenshot 2023-01-13 010557](https://user-images.githubusercontent.com/111070211/212168678-52429e68-17a2-4150-9643-5706f9eadea5.jpg)

- Registration Page For Students and Companies


![Screenshot 2023-01-13 010755](https://user-images.githubusercontent.com/111070211/212170065-d00e3794-2f7c-449f-b18c-6767fc73a37e.jpg)

 
 - Login Page
 

![Screenshot 2023-01-13 013254](https://user-images.githubusercontent.com/111070211/212169229-27f3c260-ac8f-480d-a13c-178a2ded1dde.jpg)

Admin Login

![image](https://user-images.githubusercontent.com/111070211/212169400-2040c5f6-e110-42b6-bd27-8b7b18e06743.png)

Admin dashboard




![Screenshot 2023-01-13 014007](https://user-images.githubusercontent.com/111070211/212170495-0bb04ef3-83bb-459b-ba17-71b4256f396d.jpg)

coordinator dashboard

![Screenshot 2023-01-13 010827](https://user-images.githubusercontent.com/111070211/212170601-a1fe5719-50fa-4275-b4d5-c27d1ca3fe57.jpg)

- contact us

![image](https://user-images.githubusercontent.com/111070211/212170893-dbb903ec-b720-4331-9d6c-22abe6107f2a.png)

![image](https://user-images.githubusercontent.com/111070211/212171069-884f15b9-13a7-4d74-b7d4-0d46d178b359.png)


<br>
GETTING STARTED

1. Install XAMPP or WAMPP.

2. Open XAMPP Control panal and start [apache] and [mysql] .

3. Download project from github(https://github.com/atinder11/Placement-Portal).

OR follow gitbash commands

i> cd C:\\xampp\htdocs\

ii> git clone https://github.com/atinder11/Placement-Portal

4. Extract files in C:\xampp\htdocs.

5. Open link localhost/phpmyadmin

6. Click on new at side navbar.

7. Give a database name as (placement_portal) hit on create button.

8. After creating database name click on import.

9. Browse the file in directory [placement-portal/database/db1.sql].

10. Open any browser and type http://localhost/placement-portal.






















### Team Member

- [Atinder Kumar](https://github.com/atinder11)

- [Suyash Rawat](https://github.com/SuyashRawat)

- [Jatin Tagore](https://github.com/jazz1706)


